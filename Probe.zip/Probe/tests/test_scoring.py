
from probe.models import Finding
from probe.scoring import (
    count_severities,
    calculate_overall_risk,
    build_risk_summary,
)


def make_finding(severity):
    return Finding(
        name=f"Test {severity}",
        severity=severity,
        category="Test",
        description="Test finding",
    )


def test_count_severities():

    findings = [
        make_finding("MEDIUM"),
        make_finding("MEDIUM"),
        make_finding("LOW"),
        make_finding("INFO"),
    ]

    counts = count_severities(findings)

    assert counts["MEDIUM"] == 2
    assert counts["LOW"] == 1
    assert counts["INFO"] == 1
    assert counts["HIGH"] == 0


def test_overall_risk():

    findings = [
        make_finding("LOW"),
        make_finding("MEDIUM"),
    ]

    assert calculate_overall_risk(findings) == "MEDIUM"


def test_risk_summary():

    findings = [
        make_finding("HIGH"),
        make_finding("LOW"),
        make_finding("INFO"),
    ]

    summary = build_risk_summary(findings)

    assert summary["overall_risk"] == "HIGH"
    assert summary["total_findings"] == 3
    assert summary["counts"]["HIGH"] == 1

